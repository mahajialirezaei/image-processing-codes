# coding: utf-8

import cv2
import numpy as np
def detect_clock(binary_image):


    return new_image
